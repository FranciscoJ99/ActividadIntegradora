package Runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/Compras.feature",
        			"src/test/resources/Categorias.feature",
        			"src/test/resources/CuidadosHogar.feature",
        			"src/test/resources/Liquidaciones.feature",
        			"src/test/resources/OfertasRelámpago.feature",
        			"src/test/resources/ProductosDescuento.feature",
        			"src/test/resources/Supermercado.feature",
        			"src/test/resources/Titulo.feature",
        			"src/test/resources/TrabajaNosotros.feature"
        			},
        glue = {"StepDefinitios"},
        plugin = {"pretty", "html:target/cucumber/report.html"} // Opciones de reportes, puedes ajustar según tus necesidades
)
//primero extendemos la clase
public class Run extends AbstractTestNGCucumberTests {
}
