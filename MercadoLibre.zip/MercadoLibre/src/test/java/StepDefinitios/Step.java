package StepDefinitios;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import pom.*;

public class Step {
	 private WebDriver driver;
	 SupermercadoPage supermercado;
	 CuidadoHogarPage cuidadoH;
	 DescuentoPage descuento;
	 TrabajaNosotrosPage trabaja;
	 TituloPage Titulo;
	 Categorias cat;
	 Liquidaciones LIQ;
	 RelampagoPage relam;
	 ComprasPage compra;
	 
	 /*PRUEBA 1*/
	@Given("usuario ingresa a la Mercado libre")
	public void usuario_ingresa_a_la_mercado_libre() throws InterruptedException{
		supermercado = new SupermercadoPage(driver);
		 driver = supermercado.chromeDriverConnection();
		 supermercado.visit("https://www.mercadolibre.com.mx/");
	}
	@When("da un clic a pestania supermercado del menu")
	public void da_un_clic_a_pestania_supermercado_del_menu() throws InterruptedException{
	    supermercado.clickBtnSupermercado(); 
	}
	@Then("visitar supermercado")
	public void visitar_supermercado() {
		 assertEquals("NUESTRAS CATEGORÍAS", supermercado.MessageSM());
		 System.out.print("***Estas en el apartado de Supermercado******");
	}
			/*PRUEBA 2*/
	@When("da un clic Cuidado Del Hogar")
	public void da_un_clic_cuidado_del_hogar() throws InterruptedException {
		cuidadoH = new CuidadoHogarPage(driver);
		cuidadoH.ClckBtnCuidadoDelHogar();
	}
	
	@Then("visitar  Cuidado Del Hogar")
	public void visitar_cuidado_del_hogar() {
		 assertEquals("Cuidado del Hogar en Supermercado", cuidadoH.MessageCuidadoHogar1());
		 System.out.print("***Estas en el Apartado de Cuidado del Hogar en Supermercado******");
		}
			/*PRUEBA 3*/
	
	@When("da un clic en descuento de setenta porciento")
	public void da_un_clic_en_descuento_de_setenta_porciento() throws InterruptedException {
		descuento = new DescuentoPage(driver);
		descuento.ClckDescuento();
	}
	
	@Then("indicar en consola dende se encuentra")
	public void indicar_en_consola_dende_se_encuentra() {
	    System.out.print("estas en resultado de descuentos");
	}
	// PRUEBA 4
	
	@When("da un clic a pestania Trabaja con nosotros")
	public void da_un_clic_a_pestania_trabaja_con_nosotros() throws InterruptedException {
		trabaja = new TrabajaNosotrosPage(driver);
		trabaja.clickbtnTrabajaNosotros();
	}
	
	@When("da un clic Ver oportunidades")
	public void da_un_clic_ver_oportunidades() throws InterruptedException {
	   trabaja.clickbtnVerOportunidad();
	}
	
	@Then("indicar en consola trabajos con nosotros")
	public void indicar_en_consola_trabajos_con_nosotros() throws InterruptedException {
		System.out.print("***ESTAS EN EL APARTADO DE TRABAJA NOSOTROS******");
		//assertEquals("Oportunidades en MELI", trabaja.indicador());	 
	}
	//PRUEBA 5°
	
	
	@When("dar un click el primer producto")
	public void dar_un_click_el_primer_producto()throws InterruptedException {
		Titulo.btnproducto();
	}
	
	@Then("indcar en la consola")
	public void indcar_en_la_consola() {
		assertEquals("Xiaomi Pocophone Poco M5 (5 Mpx) Dual SIM 128 GB black 6 GB RAM",Titulo.Titulo1());
		 System.out.print("***Estas en el Apartado de Cuidado del Hogar en Supermercado******");
	}
	//PRUEBA 7°
	@When("da un clic a pestania categorias")
	public void da_un_clic_a_pestania_categorias() throws InterruptedException {
		cat = new Categorias(driver);
		cat.ClckBtnCategorias();
	}
	
	@Then("visitar")
	public void visitar() {
		System.out.print("***ESTAS EN EL APARTADO DE CATEGORIAS EN EL DEPARTAMETO MODA******");
	}
	
	///PRUEBA 8°
	
	@When("da un clic a pestania ofertas del menu")
	public void da_un_clic_a_pestania_ofertas_del_menu() throws InterruptedException {
		LIQ = new Liquidaciones(driver);
		LIQ.clickBtnOfertas();
	}
	
	@When("da un clic a  LlQUIDACIONES")
	public void da_un_clic_a_ll_quidaciones() throws InterruptedException {
		LIQ.clickLiquidacion();
	}
	
	@Then("visitar LlQUIDACIONES en conslola")
	public void visitar_ll_quidaciones_en_conslola() {
		System.out.print("***ESTAS EN EL APARTADO DE CATEGORIAS  EN LA DIVISION DE LlQUIDACIONES ******");
	}
	
	//PRUEBA 9°
	
	@When("da un clic a  ofertas de relampago")
	public void da_un_clic_a_ofertas_de_relampago() throws InterruptedException {
		relam = new RelampagoPage(driver);
		relam.clickBtnRelampago();
	}
	
	@Then("visitar ofertas de relampago en conslola")
	public void visitar_ofertas_de_relampago_en_conslola() {
		System.out.print("***ESTAS EN EL APARTADO DE CATEGORIAS  EN LA DIVISION DE Relampago ******");
	}
	//10°
	@When("da un clicl el producto")
	public void da_un_clicl_el_producto() throws InterruptedException {
		compra = new ComprasPage(driver);
		compra.clickproducto();
	}
	@Then("visitar conslola	datos")
	public void visitar_conslola_datos() throws InterruptedException {
		System.out.print("***Alberca Estructural Rectangular******");
		
	}
}
