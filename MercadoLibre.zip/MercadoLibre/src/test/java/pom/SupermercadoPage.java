package pom;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SupermercadoPage extends Base {
	public SupermercadoPage(WebDriver driver) {
        super(driver);
     } 
	By BtnSupermercado = By.linkText("Supermercado");
	By  ImgRegisterPageLocator = By.xpath("//*[@class=\"title\"]"); 
	By LabelMessageConfirm = By.xpath("//h2[contains(text(),'NUESTRAS CATEGORÍAS')]");
	
	public void clickBtnSupermercado() throws InterruptedException {
	    Thread.sleep(2000);
	    click(BtnSupermercado);
		}
	  public String MessageSM(){
	        isDisplayed(LabelMessageConfirm);
	        String result = getText(LabelMessageConfirm);
	        return result;
	    }
}