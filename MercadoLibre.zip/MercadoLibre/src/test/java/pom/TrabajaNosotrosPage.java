package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TrabajaNosotrosPage extends Base {

	public TrabajaNosotrosPage(WebDriver driver) {
		super(driver);		
	}
	By btnTrabajaNosotros = By.linkText("Trabaja con nosotros");
	By btnVerOportunidad = By.linkText("Ver oportunidades");
	By txtImg = By.linkText("//h1[contains(text(),'Oportunidades en MELI')]");
	
	public void clickbtnTrabajaNosotros() throws InterruptedException{
		Thread.sleep(4000);
		click(btnTrabajaNosotros);
	}
	public void clickbtnVerOportunidad() throws InterruptedException{
		Thread.sleep(4000);
		click(btnVerOportunidad);
	}
	public String indicador() throws InterruptedException{
		 isDisplayed(txtImg);
	        String result = getText(txtImg);
	        return result;
	}
}
