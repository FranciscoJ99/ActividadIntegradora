package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RelampagoPage extends Base{

	public RelampagoPage(WebDriver driver) {
		super(driver);
	}
	By BtnRelampago = By.xpath("//*[@src=\"https://http2.mlstatic.com/storage/splinter-admin/o:f_webp,q_auto:best/1589556042906-relampago@3x.png\"]");
	
	
	
	public void clickBtnRelampago() throws InterruptedException {
	    Thread.sleep(2000);
	    click(BtnRelampago);
		}

}
