package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ComprasPage extends Base{

	public ComprasPage(WebDriver driver) {
		super(driver);
	}
	By BtnProducto = By.xpath("//*[@src=\"https://http2.mlstatic.com/D_Q_NP_738132-MLU69364838331_052023-W.webp\"]");
	
	By txtproducto = By.linkText("Alberca Estructural Rectangular");
	By IMAGEN = By.xpath("src=\"https://http2.mlstatic.com/D_Q_NP_861413-MLU70044862272_062023-R.webp\"");

	
	public void clickproducto() throws InterruptedException {
	    Thread.sleep(2000);
	    click(BtnProducto);
		}
	public String inftxtproducto()  {
	   if( isDisplayed(txtproducto)) {
		   String result = getText(txtproducto);
	        return result;
	   }else {
		   System.out.print("ERROR DE INFORMACION");
	   }
	return null;
	    
		}
}
