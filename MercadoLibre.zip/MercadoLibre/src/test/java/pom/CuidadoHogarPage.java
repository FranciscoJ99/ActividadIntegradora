package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CuidadoHogarPage extends Base{

	public CuidadoHogarPage(WebDriver driver) {
		super(driver);
		
	}
	By BtnCuidadoDelHogar= By.xpath("//*[@alt=\"Cuidado Del Hogar\"]");
	By  MessageCHogar = By.xpath("//h1[contains(text(),'Cuidado del Hogar en Supermercado')]"); 
	
	public void ClckBtnCuidadoDelHogar() throws InterruptedException {
				Thread.sleep(2000);
			    click(BtnCuidadoDelHogar);
		}
	
	
	public String MessageCuidadoHogar1() {
		isDisplayed(MessageCHogar);
        String result = getText(MessageCHogar);
        return result;
	}
}
