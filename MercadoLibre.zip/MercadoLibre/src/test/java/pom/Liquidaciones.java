package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Liquidaciones extends Base {

	public Liquidaciones(WebDriver driver) {
		super(driver);
	}
	By BtnOfertas = By.linkText("Ofertas");
	By BtnLiquidacion = By.xpath("//*[@src=\"https://http2.mlstatic.com/storage/splinter-admin/o:f_webp,q_auto:best/1604083032911-sale2x.png\"]");
	
	
	By  ImgRegisterPageLocator = By.xpath("//*[@class=\"title\"]"); 
	By LabelMessageConfirm = By.xpath("//h2[contains(text(),'NUESTRAS CATEGORÍAS')]");
	
	public void clickBtnOfertas() throws InterruptedException {
	    Thread.sleep(2000);
	    click(BtnOfertas);
		}
	
	public void clickLiquidacion() throws InterruptedException {
	    Thread.sleep(2000);
	    click(BtnLiquidacion);
		}
	  public String MessageSM(){
	        isDisplayed(LabelMessageConfirm);
	        String result = getText(LabelMessageConfirm);
	        return result;
	    }
}
