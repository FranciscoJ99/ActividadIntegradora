package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TituloPage extends Base{

	public TituloPage(WebDriver driver) {
		super(driver);
	}
	By  btnproducto = By.linkText("//*[@src=\"https://http2.mlstatic.com/D_Q_NP_858267-MLA51811704234_102022-AB.webp\"]"); 
	By txtTitulo = By.xpath("//a[contains(text(),'Xiaomi Pocophone Poco M5 (5 Mpx) Dual SIM 128 GB black 6 GB RAM')]");
	By txtImg = By.linkText("//a[contains(text(),'Xiaomi Pocophone Poco M5 (5 Mpx) Dual SIM 128 GB black 6 GB RAM')]"); 
	
	public void btnproducto() throws InterruptedException {
		Thread.sleep(2000);
			click(btnproducto);
	}
	public String Titulo1() {
		 isDisplayed(txtImg);
	        String result = getText(txtTitulo);
	        return result;
	}
}