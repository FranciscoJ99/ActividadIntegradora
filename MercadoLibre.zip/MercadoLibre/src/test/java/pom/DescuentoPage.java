package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DescuentoPage extends Base {

	public DescuentoPage(WebDriver driver) {
		super(driver);
	}
	By  txttituloDescuento = By.linkText("(//h3[@class='ui-search-filter-dt-title shops-custom-primary-font'])[4]");
	By txtDescuento = By.xpath("(//*[@class='ui-search-filter-container shops__container-lists\'])[20]");
	
	public void ClckDescuento() throws InterruptedException {
		isDisplayed(txttituloDescuento);
		Thread.sleep(2000);
		click(txtDescuento);
		}
	
}
