package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Categorias extends Base {

	public Categorias(WebDriver driver) {
		super(driver);
		
	}
	By BtnCategorias= By.linkText("Categorías");
	
	By btnmenucat = By.xpath("(//*[@class=\"nav-categs-departments__list nav-categs-departments__list--static\"])[5]"); 
	
	public void ClckBtnCategorias() throws InterruptedException {
		Thread.sleep(2000);
	    click(BtnCategorias);
	    Thread.sleep(2000);
	    click(btnmenucat);
}
	
	
	
}
